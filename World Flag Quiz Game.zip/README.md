
  # World Flag Quiz Game

  This is a code bundle for World Flag Quiz Game. The original project is available at https://www.figma.com/design/8HXKk7k7ljc53Az5hThXeA/World-Flag-Quiz-Game.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  