import { FlagQuizGame } from './components/FlagQuizGame';

export default function App() {
  return (
    <div className="size-full">
      <FlagQuizGame />
    </div>
  );
}
