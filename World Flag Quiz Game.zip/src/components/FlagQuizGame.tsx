import { useState, useEffect } from 'react';
import { WelcomeScreen } from './WelcomeScreen';
import { GameScreen } from './GameScreen';
import { ResultScreen } from './ResultScreen';

export type GameState = 'welcome' | 'playing' | 'result';
export type QuizType = 'flags' | 'capitals' | 'landmarks';
export type Difficulty = 'easy' | 'medium' | 'hard';

export interface CountryData {
  name: string;
  nameCN: string;
  flag: string;
  capital: string;
  capitalCN: string;
  landmark: string;
  landmarkCN: string;
}

export const countries: CountryData[] = [
  { name: "United States", nameCN: "美国", flag: "🇺🇸", capital: "Washington D.C.", capitalCN: "华盛顿特区", landmark: "Statue of Liberty", landmarkCN: "自由女神像" },
  { name: "China", nameCN: "中国", flag: "🇨🇳", capital: "Beijing", capitalCN: "北京", landmark: "Great Wall", landmarkCN: "长城" },
  { name: "Japan", nameCN: "日本", flag: "🇯🇵", capital: "Tokyo", capitalCN: "东京", landmark: "Mount Fuji", landmarkCN: "富士山" },
  { name: "United Kingdom", nameCN: "英国", flag: "🇬🇧", capital: "London", capitalCN: "伦敦", landmark: "Big Ben", landmarkCN: "大本钟" },
  { name: "France", nameCN: "法国", flag: "🇫🇷", capital: "Paris", capitalCN: "巴黎", landmark: "Eiffel Tower", landmarkCN: "埃菲尔铁塔" },
  { name: "Germany", nameCN: "德国", flag: "🇩🇪", capital: "Berlin", capitalCN: "柏林", landmark: "Brandenburg Gate", landmarkCN: "勃兰登堡门" },
  { name: "Italy", nameCN: "意大利", flag: "🇮🇹", capital: "Rome", capitalCN: "罗马", landmark: "Colosseum", landmarkCN: "斗兽场" },
  { name: "Spain", nameCN: "西班牙", flag: "🇪🇸", capital: "Madrid", capitalCN: "马德里", landmark: "Sagrada Familia", landmarkCN: "圣家堂" },
  { name: "Canada", nameCN: "加拿大", flag: "🇨🇦", capital: "Ottawa", capitalCN: "渥太华", landmark: "CN Tower", landmarkCN: "加拿大国家电视塔" },
  { name: "Australia", nameCN: "澳大利亚", flag: "🇦🇺", capital: "Canberra", capitalCN: "堪培拉", landmark: "Sydney Opera House", landmarkCN: "悉尼歌剧院" },
  { name: "Brazil", nameCN: "巴西", flag: "🇧🇷", capital: "Brasília", capitalCN: "巴西利亚", landmark: "Christ the Redeemer", landmarkCN: "救世基督像" },
  { name: "Mexico", nameCN: "墨西哥", flag: "🇲🇽", capital: "Mexico City", capitalCN: "墨西哥城", landmark: "Chichen Itza", landmarkCN: "奇琴伊察" },
  { name: "South Korea", nameCN: "韩国", flag: "🇰🇷", capital: "Seoul", capitalCN: "首尔", landmark: "N Seoul Tower", landmarkCN: "首尔塔" },
  { name: "India", nameCN: "印度", flag: "🇮🇳", capital: "New Delhi", capitalCN: "新德里", landmark: "Taj Mahal", landmarkCN: "泰姬陵" },
  { name: "Russia", nameCN: "俄罗斯", flag: "🇷🇺", capital: "Moscow", capitalCN: "莫斯科", landmark: "Red Square", landmarkCN: "红场" },
  { name: "Argentina", nameCN: "阿根廷", flag: "🇦🇷", capital: "Buenos Aires", capitalCN: "布宜诺斯艾利斯", landmark: "Obelisco", landmarkCN: "方尖碑" },
  { name: "Netherlands", nameCN: "荷兰", flag: "🇳🇱", capital: "Amsterdam", capitalCN: "阿姆斯特丹", landmark: "Windmills", landmarkCN: "风车" },
  { name: "Sweden", nameCN: "瑞典", flag: "🇸🇪", capital: "Stockholm", capitalCN: "斯德哥尔摩", landmark: "Vasa Museum", landmarkCN: "瓦萨博物馆" },
  { name: "Switzerland", nameCN: "瑞士", flag: "🇨🇭", capital: "Bern", capitalCN: "伯尔尼", landmark: "Matterhorn", landmarkCN: "马特洪峰" },
  { name: "Belgium", nameCN: "比利时", flag: "🇧🇪", capital: "Brussels", capitalCN: "布鲁塞尔", landmark: "Atomium", landmarkCN: "原子球塔" },
  { name: "Poland", nameCN: "波兰", flag: "🇵🇱", capital: "Warsaw", capitalCN: "华沙", landmark: "Wawel Castle", landmarkCN: "瓦维尔城堡" },
  { name: "Turkey", nameCN: "土耳其", flag: "🇹🇷", capital: "Ankara", capitalCN: "安卡拉", landmark: "Hagia Sophia", landmarkCN: "圣索菲亚大教堂" },
  { name: "Thailand", nameCN: "泰国", flag: "🇹🇭", capital: "Bangkok", capitalCN: "曼谷", landmark: "Grand Palace", landmarkCN: "大皇宫" },
  { name: "Vietnam", nameCN: "越南", flag: "🇻🇳", capital: "Hanoi", capitalCN: "河内", landmark: "Ha Long Bay", landmarkCN: "下龙湾" },
  { name: "Egypt", nameCN: "埃及", flag: "🇪🇬", capital: "Cairo", capitalCN: "开罗", landmark: "Pyramids of Giza", landmarkCN: "吉萨金字塔" },
  { name: "South Africa", nameCN: "南非", flag: "🇿🇦", capital: "Pretoria", capitalCN: "比勒陀利亚", landmark: "Table Mountain", landmarkCN: "桌山" },
  { name: "Greece", nameCN: "希腊", flag: "🇬🇷", capital: "Athens", capitalCN: "雅典", landmark: "Parthenon", landmarkCN: "帕特农神庙" },
  { name: "Portugal", nameCN: "葡萄牙", flag: "🇵🇹", capital: "Lisbon", capitalCN: "里斯本", landmark: "Belém Tower", landmarkCN: "贝伦塔" },
  { name: "Norway", nameCN: "挪威", flag: "🇳🇴", capital: "Oslo", capitalCN: "奥斯陆", landmark: "Fjords", landmarkCN: "峡湾" },
  { name: "Denmark", nameCN: "丹麦", flag: "🇩🇰", capital: "Copenhagen", capitalCN: "哥本哈根", landmark: "Little Mermaid", landmarkCN: "小美人鱼" },
  { name: "Finland", nameCN: "芬兰", flag: "🇫🇮", capital: "Helsinki", capitalCN: "赫尔辛基", landmark: "Helsinki Cathedral", landmarkCN: "赫尔辛基大教堂" },
  { name: "Ireland", nameCN: "爱尔兰", flag: "🇮🇪", capital: "Dublin", capitalCN: "都柏林", landmark: "Cliffs of Moher", landmarkCN: "莫赫悬崖" },
  { name: "Singapore", nameCN: "新加坡", flag: "🇸🇬", capital: "Singapore", capitalCN: "新加坡", landmark: "Marina Bay Sands", landmarkCN: "滨海湾金沙" },
  { name: "Malaysia", nameCN: "马来西亚", flag: "🇲🇾", capital: "Kuala Lumpur", capitalCN: "吉隆坡", landmark: "Petronas Towers", landmarkCN: "双子塔" },
  { name: "Philippines", nameCN: "菲律宾", flag: "🇵🇭", capital: "Manila", capitalCN: "马尼拉", landmark: "Chocolate Hills", landmarkCN: "巧克力山" },
];

export const difficultyConfig = {
  easy: {
    name: "Novice Navigator",
    nameCN: "新手导航员",
    aiAccuracy: 0.4,
    aiName: "Beginner Bot",
    aiNameCN: "初级机器人"
  },
  medium: {
    name: "World Explorer",
    nameCN: "世界探险家",
    aiAccuracy: 0.65,
    aiName: "Smart Traveler",
    aiNameCN: "智能旅行家"
  },
  hard: {
    name: "Geography Master",
    nameCN: "地理大师",
    aiAccuracy: 0.85,
    aiName: "Expert Guide",
    aiNameCN: "专家向导"
  }
};

export function FlagQuizGame() {
  const [gameState, setGameState] = useState<GameState>('welcome');
  const [playerName, setPlayerName] = useState('');
  const [quizType, setQuizType] = useState<QuizType>('flags');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [currentScore, setCurrentScore] = useState(0);
  const [aiScore, setAiScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [highScorePlayer, setHighScorePlayer] = useState('');

  useEffect(() => {
    const savedHighScore = localStorage.getItem('worldQuizHighScore');
    const savedPlayer = localStorage.getItem('worldQuizHighScorePlayer');
    if (savedHighScore) {
      setHighScore(parseInt(savedHighScore));
    }
    if (savedPlayer) {
      setHighScorePlayer(savedPlayer);
    }
  }, []);

  const startGame = (name: string, type: QuizType, diff: Difficulty) => {
    setPlayerName(name);
    setQuizType(type);
    setDifficulty(diff);
    setCurrentScore(0);
    setAiScore(0);
    setGameState('playing');
  };

  const endGame = (finalScore: number, finalAiScore: number) => {
    setCurrentScore(finalScore);
    setAiScore(finalAiScore);
    
    if (finalScore > highScore) {
      setHighScore(finalScore);
      setHighScorePlayer(playerName);
      localStorage.setItem('worldQuizHighScore', finalScore.toString());
      localStorage.setItem('worldQuizHighScorePlayer', playerName);
    }
    
    setGameState('result');
  };

  const resetGame = () => {
    setGameState('welcome');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      {gameState === 'welcome' && (
        <WelcomeScreen 
          onStart={startGame}
          highScore={highScore}
          highScorePlayer={highScorePlayer}
        />
      )}
      {gameState === 'playing' && (
        <GameScreen 
          playerName={playerName}
          quizType={quizType}
          difficulty={difficulty}
          onGameEnd={endGame}
        />
      )}
      {gameState === 'result' && (
        <ResultScreen
          playerName={playerName}
          score={currentScore}
          aiScore={aiScore}
          difficulty={difficulty}
          highScore={highScore}
          highScorePlayer={highScorePlayer}
          onPlayAgain={resetGame}
        />
      )}
    </div>
  );
}
