import { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Timer, Trophy, Bot, User } from 'lucide-react';
import { countries, type CountryData, type QuizType, type Difficulty, difficultyConfig } from './FlagQuizGame';

interface GameScreenProps {
  playerName: string;
  quizType: QuizType;
  difficulty: Difficulty;
  onGameEnd: (score: number, aiScore: number) => void;
}

interface Question {
  correctAnswer: CountryData;
  options: CountryData[];
}

const MAX_QUESTIONS = 15;
const TIME_PER_QUESTION = 15;

export function GameScreen({ playerName, quizType, difficulty, onGameEnd }: GameScreenProps) {
  const [score, setScore] = useState(0);
  const [aiScore, setAiScore] = useState(0);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [timeLeft, setTimeLeft] = useState(TIME_PER_QUESTION);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [aiSelectedAnswer, setAiSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [usedCountries, setUsedCountries] = useState<Set<number>>(new Set());

  const getQuestionContent = (country: CountryData) => {
    switch (quizType) {
      case 'flags':
        return { display: country.flag, questionEN: 'Which country does this flag belong to?', questionCN: '这面国旗属于哪个国家？' };
      case 'capitals':
        return { display: `${country.capital} / ${country.capitalCN}`, questionEN: 'Which country has this capital?', questionCN: '哪个国家的首都是这个？' };
      case 'landmarks':
        return { display: `${country.landmark} / ${country.landmarkCN}`, questionEN: 'Which country has this landmark?', questionCN: '哪个国家有这个地标？' };
    }
  };

  const generateQuestion = useCallback(() => {
    const availableIndices = countries
      .map((_, index) => index)
      .filter(index => !usedCountries.has(index));

    if (availableIndices.length < 4) {
      onGameEnd(score, aiScore);
      return;
    }

    const shuffled = [...availableIndices].sort(() => Math.random() - 0.5);
    const correctIndex = shuffled[0];
    const wrongIndices = shuffled.slice(1, 4);

    const correctAnswer = countries[correctIndex];
    const options = [
      correctAnswer,
      countries[wrongIndices[0]],
      countries[wrongIndices[1]],
      countries[wrongIndices[2]]
    ].sort(() => Math.random() - 0.5);

    setCurrentQuestion({
      correctAnswer,
      options
    });

    setUsedCountries(prev => new Set([...prev, correctIndex]));

    // AI makes its decision
    const correctOptionIndex = options.findIndex(opt => opt === correctAnswer);
    const aiAccuracy = difficultyConfig[difficulty].aiAccuracy;
    
    setTimeout(() => {
      if (Math.random() < aiAccuracy) {
        setAiSelectedAnswer(correctOptionIndex);
      } else {
        const wrongOptions = options.map((_, idx) => idx).filter(idx => idx !== correctOptionIndex);
        const randomWrong = wrongOptions[Math.floor(Math.random() * wrongOptions.length)];
        setAiSelectedAnswer(randomWrong);
      }
    }, Math.random() * 3000 + 1000); // AI answers between 1-4 seconds

  }, [usedCountries, score, aiScore, onGameEnd, difficulty]);

  useEffect(() => {
    generateQuestion();
  }, []);

  useEffect(() => {
    if (isAnswered || timeLeft === 0) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          handleTimeOut();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isAnswered]);

  const handleTimeOut = () => {
    setIsAnswered(true);
    
    // Check if AI was correct
    if (aiSelectedAnswer !== null && currentQuestion?.options[aiSelectedAnswer] === currentQuestion?.correctAnswer) {
      setAiScore(prev => prev + 1);
    }

    setTimeout(() => {
      nextQuestion();
    }, 1500);
  };

  const handleAnswer = (index: number) => {
    if (isAnswered) return;

    setSelectedAnswer(index);
    setIsAnswered(true);

    const isCorrect = currentQuestion?.options[index] === currentQuestion?.correctAnswer;
    
    if (isCorrect) {
      setScore(prev => prev + 1);
    }

    // Check if AI was correct
    if (aiSelectedAnswer !== null && currentQuestion?.options[aiSelectedAnswer] === currentQuestion?.correctAnswer) {
      setAiScore(prev => prev + 1);
    }

    setTimeout(() => {
      nextQuestion();
    }, 1500);
  };

  const nextQuestion = () => {
    if (questionNumber >= MAX_QUESTIONS) {
      const finalPlayerScore = score + (selectedAnswer !== null && currentQuestion?.options[selectedAnswer] === currentQuestion?.correctAnswer ? 1 : 0);
      const finalAiScore = aiScore + (aiSelectedAnswer !== null && currentQuestion?.options[aiSelectedAnswer] === currentQuestion?.correctAnswer ? 1 : 0);
      onGameEnd(finalPlayerScore, finalAiScore);
      return;
    }

    setQuestionNumber(prev => prev + 1);
    setTimeLeft(TIME_PER_QUESTION);
    setSelectedAnswer(null);
    setAiSelectedAnswer(null);
    setIsAnswered(false);
    generateQuestion();
  };

  const getButtonVariant = (index: number) => {
    if (!isAnswered) return 'outline';
    
    const isCorrect = currentQuestion?.options[index] === currentQuestion?.correctAnswer;
    const isSelected = selectedAnswer === index;

    if (isCorrect) return 'default';
    if (isSelected && !isCorrect) return 'destructive';
    return 'outline';
  };

  const getButtonClassName = (index: number) => {
    if (!isAnswered) return '';
    
    const isAiSelected = aiSelectedAnswer === index;
    if (isAiSelected) return 'ring-2 ring-purple-400';
    return '';
  };

  if (!currentQuestion) return null;

  const timeProgress = (timeLeft / TIME_PER_QUESTION) * 100;
  const questionContent = getQuestionContent(currentQuestion.correctAnswer);
  const aiConfig = difficultyConfig[difficulty];

  return (
    <Card className="w-full max-w-2xl shadow-xl">
      <CardHeader>
        <div className="flex justify-between items-center mb-4 gap-4">
          <div className="flex items-center gap-2 flex-1">
            <User className="w-4 h-4" />
            <Badge variant="secondary" className="text-sm px-3 py-1">
              {playerName}
            </Badge>
            <Badge variant="default" className="text-sm px-3 py-1 flex items-center gap-1">
              <Trophy className="w-3 h-3" />
              {score}
            </Badge>
          </div>
          
          <div className="flex items-center gap-2 flex-1 justify-end">
            <Badge variant="default" className="text-sm px-3 py-1 flex items-center gap-1 bg-purple-600">
              <Trophy className="w-3 h-3" />
              {aiScore}
            </Badge>
            <Badge variant="secondary" className="text-sm px-3 py-1 bg-purple-100">
              {aiConfig.aiName}
            </Badge>
            <Bot className="w-4 h-4 text-purple-600" />
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <CardTitle>
              Question {questionNumber} / {MAX_QUESTIONS}
            </CardTitle>
            <Badge 
              variant={timeLeft <= 5 ? 'destructive' : 'default'}
              className="flex items-center gap-1 px-3 py-1"
            >
              <Timer className="w-4 h-4" />
              {timeLeft}s
            </Badge>
          </div>
          <Progress value={timeProgress} className="h-2" />
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className={`bg-gradient-to-br from-blue-100 to-indigo-100 p-8 rounded-lg flex flex-col justify-center items-center min-h-[200px] ${
          quizType === 'flags' ? '' : 'gap-2'
        }`}>
          {quizType === 'flags' ? (
            <div className="text-9xl">
              {questionContent.display}
            </div>
          ) : (
            <>
              <div className="text-4xl text-center">{questionContent.display.split(' / ')[0]}</div>
              <div className="text-2xl text-center text-muted-foreground">{questionContent.display.split(' / ')[1]}</div>
            </>
          )}
        </div>

        <div className="space-y-3">
          <p className="text-center text-muted-foreground">
            {questionContent.questionEN} / {questionContent.questionCN}
          </p>
          <div className="grid grid-cols-1 gap-3">
            {currentQuestion.options.map((option, index) => (
              <Button
                key={index}
                onClick={() => handleAnswer(index)}
                variant={getButtonVariant(index)}
                disabled={isAnswered}
                className={`h-auto py-4 justify-start relative ${getButtonClassName(index)}`}
                size="lg"
              >
                <span className="text-left w-full">
                  {option.name} / {option.nameCN}
                </span>
                {isAnswered && aiSelectedAnswer === index && (
                  <Bot className="w-4 h-4 absolute right-4 text-purple-600" />
                )}
              </Button>
            ))}
          </div>
          {isAnswered && aiSelectedAnswer !== null && (
            <p className="text-center text-sm text-muted-foreground">
              Purple ring = AI's choice / 紫色边框 = AI的选择
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
