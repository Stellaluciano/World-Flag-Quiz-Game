import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Trophy, Flag, MapPin, Landmark } from 'lucide-react';
import { type QuizType, type Difficulty, difficultyConfig } from './FlagQuizGame';
import { Badge } from './ui/badge';

interface WelcomeScreenProps {
  onStart: (name: string, quizType: QuizType, difficulty: Difficulty) => void;
  highScore: number;
  highScorePlayer: string;
}

export function WelcomeScreen({ onStart, highScore, highScorePlayer }: WelcomeScreenProps) {
  const [name, setName] = useState('');
  const [quizType, setQuizType] = useState<QuizType>('flags');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');

  const handleStart = () => {
    if (name.trim()) {
      onStart(name.trim(), quizType, difficulty);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleStart();
    }
  };

  const quizTypeOptions = [
    { value: 'flags' as QuizType, icon: Flag, label: 'Flags', labelCN: '国旗' },
    { value: 'capitals' as QuizType, icon: MapPin, label: 'Capitals', labelCN: '首都' },
    { value: 'landmarks' as QuizType, icon: Landmark, label: 'Landmarks', labelCN: '地标' },
  ];

  const difficultyOptions: { value: Difficulty; color: string }[] = [
    { value: 'easy', color: 'bg-green-100 hover:bg-green-200 border-green-300' },
    { value: 'medium', color: 'bg-yellow-100 hover:bg-yellow-200 border-yellow-300' },
    { value: 'hard', color: 'bg-red-100 hover:bg-red-200 border-red-300' },
  ];

  return (
    <Card className="w-full max-w-2xl shadow-xl">
      <CardHeader className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <div className="flex gap-2">
            <span className="text-6xl">🌍</span>
            <span className="text-6xl">🎯</span>
            <span className="text-6xl">🏆</span>
          </div>
        </div>
        <CardTitle>World Geography Quiz</CardTitle>
        <CardTitle>世界地理问答游戏</CardTitle>
        <CardDescription className="space-y-1">
          <div>Test your knowledge against AI!</div>
          <div>与AI比拼你的知识！</div>
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <label htmlFor="playerName" className="block">
            Enter your name / 输入您的姓名:
          </label>
          <Input
            id="playerName"
            type="text"
            placeholder="Your name / 您的姓名"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyPress={handleKeyPress}
            className="w-full"
          />
        </div>

        <div className="space-y-3">
          <label className="block">
            Select Quiz Type / 选择问答类型:
          </label>
          <div className="grid grid-cols-3 gap-3">
            {quizTypeOptions.map((option) => {
              const Icon = option.icon;
              return (
                <button
                  key={option.value}
                  onClick={() => setQuizType(option.value)}
                  className={`p-4 rounded-lg border-2 transition-all flex flex-col items-center gap-2 ${
                    quizType === option.value
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:border-primary/50'
                  }`}
                >
                  <Icon className="w-6 h-6" />
                  <div className="text-center">
                    <div>{option.label}</div>
                    <div className="text-sm text-muted-foreground">{option.labelCN}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-3">
          <label className="block">
            Select Difficulty / 选择难度:
          </label>
          <div className="grid grid-cols-1 gap-2">
            {difficultyOptions.map((option) => {
              const config = difficultyConfig[option.value];
              return (
                <button
                  key={option.value}
                  onClick={() => setDifficulty(option.value)}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    difficulty === option.value
                      ? 'border-primary ring-2 ring-primary/20'
                      : 'border-border'
                  } ${option.color}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="text-left">
                      <div>{config.name} / {config.nameCN}</div>
                      <div className="text-sm text-muted-foreground mt-1">
                        AI Opponent: {config.aiName} / {config.aiNameCN}
                      </div>
                    </div>
                    <Badge variant="secondary">
                      {Math.round(config.aiAccuracy * 100)}% AI
                    </Badge>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="bg-muted p-4 rounded-lg space-y-2">
          <h3 className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            Game Rules / 游戏规则
          </h3>
          <ul className="space-y-1 ml-6">
            <li>• 15 seconds per round / 每轮15秒</li>
            <li>• 15 questions total / 总共15题</li>
            <li>• Compete against AI / 与AI竞争</li>
            <li>• Choose the correct answer / 选择正确答案</li>
          </ul>
        </div>

        {highScore > 0 && (
          <div className="bg-gradient-to-r from-yellow-50 to-amber-50 border-2 border-yellow-300 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="w-6 h-6 text-yellow-600" />
              <h3>Record Score / 最高分数</h3>
            </div>
            <p className="text-2xl">
              {highScorePlayer}: {highScore} / 15
            </p>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button 
          onClick={handleStart} 
          disabled={!name.trim()}
          className="w-full"
          size="lg"
        >
          Start Game / 开始游戏
        </Button>
      </CardFooter>
    </Card>
  );
}
