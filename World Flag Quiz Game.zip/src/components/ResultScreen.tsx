import { Card, CardHeader, CardTitle, CardContent, CardFooter } from './ui/card';
import { Button } from './ui/button';
import { Trophy, Award, Medal, RotateCcw, User, Bot } from 'lucide-react';
import { type Difficulty, difficultyConfig } from './FlagQuizGame';

interface ResultScreenProps {
  playerName: string;
  score: number;
  aiScore: number;
  difficulty: Difficulty;
  highScore: number;
  highScorePlayer: string;
  onPlayAgain: () => void;
}

export function ResultScreen({ 
  playerName, 
  score,
  aiScore,
  difficulty,
  highScore, 
  highScorePlayer,
  onPlayAgain 
}: ResultScreenProps) {
  const isNewRecord = score === highScore && score > 0;
  const wonAgainstAI = score > aiScore;
  const tiedWithAI = score === aiScore;
  const percentage = (score / 15) * 100;
  const aiConfig = difficultyConfig[difficulty];

  const getPerformanceMessage = () => {
    if (wonAgainstAI) {
      if (percentage === 100) return { en: "Perfect Score! You crushed the AI! 🎉", cn: "满分！你击败了AI！🎉" };
      if (percentage >= 80) return { en: "Excellent! You beat the AI! 🌟", cn: "非常棒！你击败了AI！🌟" };
      return { en: "Great Job! You won! 👏", cn: "做得好！你赢了！👏" };
    } else if (tiedWithAI) {
      return { en: "It's a Tie! 🤝", cn: "平局！🤝" };
    } else {
      return { en: "AI Won This Time! 💪", cn: "这次AI赢了！💪" };
    }
  };

  const performance = getPerformanceMessage();

  return (
    <Card className="w-full max-w-lg shadow-xl">
      <CardHeader className="text-center space-y-4">
        <div className="flex justify-center">
          {isNewRecord ? (
            <Trophy className="w-20 h-20 text-yellow-500" />
          ) : wonAgainstAI ? (
            <Award className="w-20 h-20 text-blue-500" />
          ) : (
            <Medal className="w-20 h-20 text-gray-500" />
          )}
        </div>
        
        <div>
          <CardTitle className="mb-2">
            {isNewRecord ? 'New Record! 🎊' : 'Game Over!'}
          </CardTitle>
          <CardTitle className="mb-4">
            {isNewRecord ? '新纪录！🎊' : '游戏结束！'}
          </CardTitle>
        </div>

        <div className="space-y-1">
          <p>{performance.en}</p>
          <p>{performance.cn}</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className={`p-4 rounded-lg ${wonAgainstAI ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-300' : 'bg-muted'}`}>
            <div className="flex items-center justify-center gap-2 mb-2">
              <User className="w-5 h-5" />
              <h3>{playerName}</h3>
            </div>
            <div className="text-4xl">
              {score} / 15
            </div>
          </div>

          <div className={`p-4 rounded-lg ${!wonAgainstAI && !tiedWithAI ? 'bg-gradient-to-br from-purple-50 to-indigo-50 border-2 border-purple-300' : 'bg-muted'}`}>
            <div className="flex items-center justify-center gap-2 mb-2">
              <Bot className="w-5 h-5 text-purple-600" />
              <h3 className="text-sm">{aiConfig.aiNameCN}</h3>
            </div>
            <div className="text-4xl">
              {aiScore} / 15
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {isNewRecord && (
          <div className="bg-gradient-to-r from-yellow-50 to-amber-50 border-2 border-yellow-300 p-4 rounded-lg text-center">
            <p className="mb-1">🎉 Congratulations! You set a new record! 🎉</p>
            <p>🎉 恭喜！您创造了新纪录！🎉</p>
          </div>
        )}

        {!isNewRecord && highScore > 0 && (
          <div className="bg-muted p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="w-5 h-5 text-yellow-600" />
              <h3>Record Score / 最高分数</h3>
            </div>
            <p className="text-xl">
              {highScorePlayer}: {highScore} / 15
            </p>
          </div>
        )}

        <div className="bg-muted p-4 rounded-lg space-y-3">
          <h3>Match Details / 比赛详情</h3>
          
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Difficulty / 难度:</span>
              <span>{aiConfig.name} / {aiConfig.nameCN}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Your Accuracy / 您的准确率:</span>
              <span>{percentage.toFixed(1)}%</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">AI Accuracy / AI准确率:</span>
              <span>{((aiScore / 15) * 100).toFixed(1)}%</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Score Difference / 分数差:</span>
              <span className={wonAgainstAI ? 'text-green-600' : 'text-red-600'}>
                {wonAgainstAI ? '+' : ''}{score - aiScore}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-muted p-4 rounded-lg">
          <h3 className="mb-2">Your Statistics / 您的统计</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-muted-foreground">Correct / 正确</p>
              <p className="text-2xl text-green-600">{score}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Incorrect / 错误</p>
              <p className="text-2xl text-red-600">{15 - score}</p>
            </div>
          </div>
        </div>
      </CardContent>

      <CardFooter>
        <Button 
          onClick={onPlayAgain}
          className="w-full"
          size="lg"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Play Again / 再玩一次
        </Button>
      </CardFooter>
    </Card>
  );
}
